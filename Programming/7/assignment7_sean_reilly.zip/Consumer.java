/**
 * Created by Seán on 08/11/2016.
 * 14336256
 */
public class Consumer extends Thread {
    private SyncQueue<String> queue;
    private int number;

    public Consumer(SyncQueue queue, int n){
        this.queue = queue;
        number = n;
    }

    public void run(){
        String value = "";
        for (int i = 0; i < 3; i++) {
            try {
                value = queue.remove();

            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("Consumer #" +      this.number + " got: " + value +". "  +Integer.toString(queue.getSize()) +" item(s) in queue.");
        }
        try {
            sleep((int)(Math.random() * 100));
        } catch (InterruptedException e) { }
    }
}
