import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Created by Seán on 08/11/2016.
 * 14336256
 */

class SyncQueue<String> {
    private Object[] elements;
    private int head;
    private int tail;
    private int size;
    final Lock lock = new ReentrantLock();
    final Condition notFull  = lock.newCondition();
    final Condition notEmpty = lock.newCondition();

    public SyncQueue(int capacity) {
        elements = new Object[capacity];
        head = 0;
        tail = 0;
        size = 0;
    }

    public String remove() throws InterruptedException {
        lock.lock();
        try {
            while (size == 0){
                notEmpty.await();;
            }//can't take if empty
            String s = (String) elements[head];
            head++;
            size--;
            if (head == elements.length)
                head = 0;
            notEmpty.signal();
            return s;
        }finally {
            lock.unlock();
        }
    }

    public void add(String newValue) throws InterruptedException {
        lock.lock();
        try {
            while (size == elements.length)
                notFull.await();
            elements[tail] = newValue;
            tail++;
            size++;
            if (tail == elements.length)
                tail = 0;
            notEmpty.signal();
        }finally {
            lock.unlock();
        }
    }

    public int getSize(){
        return this.size;
    }

}