import javax.swing.*;
import java.io.IOException;

/**
 * Created by Seán on 10/11/2016.
 * 14336256
 */
public class ClientTest {
    public static void main(String[] args) {
        try {
            Client c1 = new Client();
            c1.setDefaultCloseOperation(
                    JFrame.EXIT_ON_CLOSE );
        } catch (IOException e1) {
            e1.printStackTrace();
        }
    }

}
