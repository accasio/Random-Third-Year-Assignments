//s. reilly - 14336256

import java.awt.*;
import javax.swing.*;

public class LightSwitch extends JFrame {


    private JButton onSwitch;
    private JButton offSwitch;
    private Container container;
    private GridBagLayout layout;
    private GridBagConstraints constraints;
    private String status1 = "Switch turned off ", status2 = "in timed status.";

    public LightSwitch()
    {
        super( "GridBagLayout" );
        container = getContentPane();
        layout = new GridBagLayout();
        container.setLayout( layout );
        constraints = new GridBagConstraints();
        String[] intensity ;
        intensity = new String[]{"1", "2", "3", "4", "5"};
        JButton button1 = new JButton( "On Switch" );
        JButton button2 = new JButton( "Off Switch" );
        JButton button3 = new JButton( "Timed" );
        JButton button4 = new JButton( "Manual" );
        JButton button5 = new JButton( "Status" );
        TextField field = new TextField("",20);
        JComboBox<String> comboBox = new JComboBox<>();
        for(String s :intensity){
            comboBox.addItem(s);
        }

        button1.addActionListener((e) -> {
            System.out.println("Switch turned on");
            status1 = "Switch turned on ";
        });
        button2.addActionListener((e) -> {
            System.out.println("Switch turned off");
            status1 = "Switch turned off ";
        });
        button3.addActionListener((e) -> {
            System.out.println("in timed position.");
            status2 = "in timed position.";
        });
        button4.addActionListener((e) -> {
            System.out.println("in manual position");
            status2 = "in manual position";
        });
        button5.addActionListener((e) -> {
            int intense = comboBox.getSelectedIndex();
            System.out.println(status1 + status2+ " With intensity set to "+intensity[intense]+".");
            field.setText(status1 + status2+ " With intensity set to "+intensity[intense]+".");
        });
        addComponent( button1, 1, 1, 2, 1 );
        addComponent( button2, 2, 1, 2, 1 );
        addComponent(comboBox, 3,1,2,1);
        addComponent( button3, 4, 1, 1, 1 );
        addComponent( button4, 4, 2, 1, 1 );
        addComponent(button5,5,1,2,1);
        addComponent(field,6,1,2,1);
        setSize( 500, 350 );
        setVisible( true );
    }

    // method to set constraints on
    private void addComponent( Component component,int row, int column, int width, int height )
    {
        // set gridx and gridy
        constraints.gridx = column;
        constraints.gridy = row;
        constraints.insets = new Insets(10,10,10,10);
        constraints.weightx = 1000; // can grow wider
        constraints.weighty = 1; // can grow taller
        constraints.fill = GridBagConstraints.BOTH;
        // set gridwidth and gridheight
        constraints.gridwidth = width;
        constraints.gridheight = height;
        // set constraints and add component
        layout.setConstraints( component, constraints );
        container.add( component );
    }

    public static void main(String[] args) {
        LightSwitch l = new LightSwitch();
        l.setDefaultCloseOperation(
        JFrame.EXIT_ON_CLOSE );
    }
}