/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package src;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Seán
 */
public class CustomerDAO {
    private static final String DATABASE_URL = "jdbc:mysql://danu6.it.nuigalway.ie:3306/mydb2476";
    private static final String USERNAME = "mydb2476i";
    private static final String PASSWORD = "mydb2476i";
    
    public List<Customer> getCustomers(){
        List<Customer> list = new ArrayList<>();
        Connection con = null;
        Statement stmt = null;
        
        
        try
        {
            con = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);
            stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM customers ORDER BY customerNumber");
            
            while (rs.next())
            {
                Customer cust = new Customer();
                cust.setCustomerNumber(rs.getInt(1));
                cust.setCustomerName(rs.getString(2));
                cust.setContactLastName(rs.getString(3));
                cust.setContactFirstName(rs.getString(4));
                cust.setPhone(rs.getString(5));
                cust.setAddressLine1(rs.getString(6));
                cust.setAddressLine2(rs.getString(7));
                cust.setCity(rs.getString(8));
                cust.setState(rs.getString(9));
                cust.setPostalCode(rs.getString(10));
                cust.setCountry(rs.getString(11));
                cust.setSalesRepEmployeeNumber(rs.getInt(12));
                cust.setCreditLimit(rs.getDouble(13));
                list.add(cust);
            }
        } catch (SQLException ex)
        {
        } finally
        {
            try
            {
                if (stmt != null)
                {
                    stmt.close();
                }
                if (con != null)
                {
                    con.close();
                }
            } catch (SQLException ex)
            {
            }
        }
        return list;
    }
}
