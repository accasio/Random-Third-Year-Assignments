import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;

/**
 * Created by Seán on 13/11/2016.
 * 14336256
 */
public class Client {
    public static void main(String args[]) throws Exception
    {
        DatagramSocket clientSocket = new DatagramSocket();
        Scanner input = new Scanner(System.in);//will be used to get string
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(baos);
        System.out.print("Enter name: ");
        String name2 = input.nextLine();
        oos.writeObject(name2);
        byte[] data = new byte[1024];
        data = baos.toByteArray();
        DatagramPacket dp = new DatagramPacket(data,data.length, InetAddress.getByName("localhost"), 1234);//send to localhost:1234
        clientSocket.send(dp);


        byte[] receiveData = new byte[1024];
        ByteArrayInputStream bais = new ByteArrayInputStream(receiveData);//can now start reading in
        DatagramPacket dp2 = new DatagramPacket(receiveData,receiveData.length);
        clientSocket.receive(dp2);
        ObjectInputStream ois = new ObjectInputStream(bais);
        String s = (String) ois.readObject();
        System.out.println(s);
    }
}
