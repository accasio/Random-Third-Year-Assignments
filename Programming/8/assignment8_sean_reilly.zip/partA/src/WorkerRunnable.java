import java.io.*;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Created by Seán on 10/11/2016.
 * 14336256
 */
public class WorkerRunnable implements Runnable {

    protected Socket clientSocket = null;
    protected String serverText   = null;

    public WorkerRunnable(Socket clientSocket, String serverText) {
        this.clientSocket = clientSocket;
        this.serverText   = serverText;
    }

    public void run() {
        System.out.println("Client Connected On Port: " + clientSocket.getLocalPort());
        ObjectInputStream ois = null;
        ObjectOutputStream oos = null;
        try {
            ois = new ObjectInputStream(clientSocket.getInputStream());
            oos = new ObjectOutputStream(clientSocket.getOutputStream());
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            File files = new File("./files/");//will hold all server files
            if (!files.exists() && !files.isDirectory()) {
                files.mkdir();
            }
            FileData fd = (FileData) ois.readUnshared();
            if(fd.getMsgType().equals("Upload")) {
                System.out.println("Uploading");
                File f = new File("./files/" + fd.getFileName());
                Files.write(f.toPath(), fd.getData());
            }
            else if (fd.getMsgType().equals("Download")){
                System.out.println("Downloading");
                File f = new File(fd.getFileName());
                Path path = Paths.get(f.getAbsolutePath());
                String name = f.getName();
                byte[] data = Files.readAllBytes(path);
                FileData fd1 = new FileData("Upload",name,data);
                oos.writeUnshared(fd1);
            }
            else if(fd.getMsgType().equals("First")){//get downloads list
                File folder = new File("./files");
                oos.writeUnshared(folder);
            }
        }catch (IOException|ClassNotFoundException e){
            e.printStackTrace();
        }
        System.out.println("Done");
        try {
            clientSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
