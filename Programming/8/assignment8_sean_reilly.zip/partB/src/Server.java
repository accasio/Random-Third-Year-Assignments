import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

/**
 * Created by Seán on 13/11/2016.
 * 14336256
 */
public class Server {
    public static void main(String args[]) throws Exception
    {
        DatagramSocket serverSocket = new DatagramSocket(1234);//server on 1234
        byte[] receiveData = new byte[1024];
        byte[] sendData = new byte[1024];
        while(true)
        {
            ByteArrayInputStream bais = new ByteArrayInputStream(receiveData);
            DatagramPacket dp = new DatagramPacket(receiveData,receiveData.length);
            serverSocket.receive(dp);
            ObjectInputStream ois = new ObjectInputStream(bais);
            String s = (String) ois.readObject();
            System.out.println("Server Recieved: "+s);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(baos);
            oos.writeObject("SERVER: "+s);
            sendData = baos.toByteArray();
            DatagramPacket dp2 = new DatagramPacket(sendData, sendData.length, dp.getAddress(), dp.getPort());
            serverSocket.send(dp2);
            bais.reset();
        }
    }
}
