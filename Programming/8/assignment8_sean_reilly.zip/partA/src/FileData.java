import java.io.Serializable;

/**
 * Created by Seán on 10/11/2016.
 * 14336256
 */
public class FileData implements Serializable{
    private String msgType;
    private String fileName;
    private byte[] data;

    public String getFileName() {
        return fileName;
    }

    public byte[] getData() {
        return data;
    }

    public String getMsgType(){return msgType;}

    public FileData(String msgType,String fileName, byte[] data) {
        this.msgType = msgType;
        this.fileName = fileName;
        this.data = data;
    }
}
