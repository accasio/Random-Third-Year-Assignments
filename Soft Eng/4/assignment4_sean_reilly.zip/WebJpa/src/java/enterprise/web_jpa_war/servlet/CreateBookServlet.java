package enterprise.web_jpa_war.servlet;

import enterprise.web_jpa_war.entity.Books;
import enterprise.web_jpa_war.entity.BooksFacade;
import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import javax.ejb.EJB;

/*import javax.persistence.PersistenceUnit;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityManager;
import javax.annotation.Resource;

import javax.transaction.UserTransaction;*/


/**
 * The sevelet class to insert Books into database
 */
@WebServlet(name="CreateBooksServlet", urlPatterns={"/CreateBooks"})
public class CreateBookServlet extends HttpServlet {
    
    //@PersistenceUnit
    //The emf corresponding to 
    //private EntityManagerFactory emf;  
    
    //@Resource
    //private UserTransaction utx;

    @EJB
    private BooksFacade  booksFacade;
    
    /** Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        //assert emf != null;  //Make sure injection went through correctly.
        //EntityManager em = null;
        

        //Get the data from user's form
        String isbn         = (String) request.getParameter("isbn");
        String title  = (String) request.getParameter("title");
        String author   = (String) request.getParameter("author");
        float price =  Float.parseFloat(request.getParameter("price"));
        int quantity = Integer.parseInt(request.getParameter("quantity"));

        //Create a books instance out of it
        Books books = new Books(isbn, title, author, price, quantity);

        //begin a transaction
        //utx.begin();
        //create an em. 
        //Since the em is created insisbne a transaction, it is associsated with 
        //the transaction
        //em = emf.createEntityManager();
        //persist the books entity
        //em.persist(books);
        //commit transaction which will trigger the em to 
        //commit newly created entity into database
        //utx.commit();
        
        booksFacade.create(books);
        //Forward to ListBooks servlet to list bookss along with the newly
        //created books above
        
        RequestDispatcher rd = request.getRequestDispatcher("ListBooksServlet");
        rd.forward(request, response);
    }
    
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }
    
    /** Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }
    
    /** Returns a short description of the servlet.
     */
    public String getServletInfo() {
        return "Short description";
    }
    // </editor-fold>
}
