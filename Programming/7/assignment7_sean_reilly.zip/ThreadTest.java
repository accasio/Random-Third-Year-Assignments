import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

/**
 * Created by Seán on 08/11/2016.
 * 14336256
 */
public class ThreadTest {
    public static void main(String[] args) {
        int MAX_VALUES = 10;//max number of items allowed in the queue
        SyncQueue<String> queue = new SyncQueue(MAX_VALUES);
        int numberThreads = 0;
        while(numberThreads == 0){
            numberThreads = (int)(Math.random() * 10);//will be 10 probs/cons at most
        }//make sure we at least have 1 prod/cons

        for(int i =0;i<numberThreads;i++){
            Runnable run = new Producer(queue,i);
            Thread thread = new Thread(run);
            thread.start();

            Runnable run2 = new Consumer(queue, i);
            Thread thread2 = new Thread(run2);
            thread2.start();
        }
    }
}
