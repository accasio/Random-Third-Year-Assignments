/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package enterprise.web_jpa_war.entity;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;

/**
 *
 * @author Seán
 */
@Stateless
public class BooksFacade extends AbstractFacade<Books> {

    @PersistenceContext(unitName = "web-jpaPU")
    private EntityManager em;

    private String namedQuery;

    public String getNamedQuery() {
        return namedQuery;
    }

    public void setNamedQuery(String namedQuery) {
        this.namedQuery = namedQuery;
    }
    
    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public BooksFacade() {
        super(Books.class);
    }
    
    public List search(String query){
        List<Books> list =this.findAll();
        List<String> authors = null;
        List<String> res = null;
        for(Books book: list){
            authors.add(book.getAuthor());
        }
        
        for(String s: authors){
            if(s.indexOf(query) != -1){
                res.add(s);
            }
        }
        return res;
    }
    
    public List findWithName(String name) {
        return em.createQuery(
            "SELECT b FROM Books b WHERE b.author LIKE :custName")
            .setParameter("custName", "%"+name+"%")
            .setMaxResults(10)
            .getResultList();
    }
}
