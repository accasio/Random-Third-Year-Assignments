import java.io.IOException;
import java.net.Socket;

/**
 * Created by Seán on 10/11/2016.
 * 14336256
 */
public class ServerTest {
    public static void main(String[] args) throws IOException {
        Server server = new Server(9000);
        new Thread(server).start();

        try {
            Thread.sleep(20 * 1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
