import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

/**
 * Created by Seán on 10/11/2016.
 * 14336256
 */
public class Client extends JFrame {
    private Container container;
    private GridBagLayout layout;
    private GridBagConstraints constraints;
    private Socket connection;
    private File uploadFile;
    private ArrayList<String> files;
    private ObjectOutputStream oos ;
    private ObjectInputStream ois;

    public Client() throws IOException {
        super("GridBagLayout");
        container = getContentPane();
        layout = new GridBagLayout();
        container.setLayout(layout);
        constraints = new GridBagConstraints();
        connection = new Socket("127.0.0.1", 9000);
        oos = new ObjectOutputStream(connection.getOutputStream());
        ois = new ObjectInputStream(connection.getInputStream());

        JButton button1 = new JButton( "Select File" );
        JLabel message = new JLabel("No file chosen");
        JLabel status1 = new JLabel("             ");
        JLabel status2 = new JLabel("             ");
        JButton upload = new JButton("Upload");
        JComboBox downloads = new JComboBox();
        JButton dlButton = new JButton("Download");

        try {
            oos.writeUnshared(new FileData("First",null,null));
            File filez = (File) ois.readUnshared();

            if(filez.listFiles().length == 0){
                downloads.disable();
                dlButton.setEnabled(false);
                status2.setText("No files on server, upload one.");
            }
            else{
                for (final File fileEntry : filez.listFiles()) {
                    downloads.addItem(fileEntry.toString());//add to combo box
                }
            }

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }catch (NullPointerException e){
            downloads.disable();
            dlButton.disable();
            status2.setText("No files on server,");
        }finally {
            connection.close();//close socket
        }
        button1.addActionListener((e) -> {
            JFileChooser fileChooser = new JFileChooser();
            int returnValue = fileChooser.showOpenDialog(null);
            if (returnValue == JFileChooser.APPROVE_OPTION) {
                uploadFile = fileChooser.getSelectedFile();
                message.setText(uploadFile.getName());
                System.out.println(uploadFile.getName());
            }

        });
        upload.addActionListener((e)->{
            try {
                if(connection.isClosed()){//recreate new socket if prev closed
                    connection = new Socket("127.0.0.1", 9000);
                    oos = new ObjectOutputStream(connection.getOutputStream());
                    ois = new ObjectInputStream(connection.getInputStream());
                }
                Path path = Paths.get(uploadFile.getAbsolutePath());//get name
                String name = uploadFile.getName();
                byte[] data = Files.readAllBytes(path);//get bytes
                FileData fd = new FileData("Upload",name,data);
                oos.writeUnshared(fd);//write to server
                status1.setForeground(Color.GREEN);
                status1.setText("Success");
            } catch (IOException | NullPointerException e1) {//error
                e1.printStackTrace();
                status1.setText("Failed");
                status1.setForeground(Color.red);
            }finally {
                try {
                    connection.close();//close conn
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
                downloads.addItem(".\\files\\"+uploadFile.getName());
                if(downloads.isDisplayable()) {
                    downloads.enable();
                    dlButton.setEnabled(true);
                    status2.setText("        ");
                }
            }
        });


        dlButton.addActionListener((e) -> {
            try {
                FileData fd = new FileData("Download",downloads.getSelectedItem().toString(),null);
                if(connection.isClosed()){
                    connection = new Socket("127.0.0.1", 9000);
                    oos = new ObjectOutputStream(connection.getOutputStream());
                    ois = new ObjectInputStream(connection.getInputStream());
                }
                oos.writeUnshared(fd);
                System.out.println(downloads.getSelectedItem().toString());

            } catch (IOException e1) {
                e1.printStackTrace();
            }finally {
                try {
                    FileData down = (FileData) ois.readUnshared();
                    FileOutputStream fos = new FileOutputStream(down.getFileName());
                    fos.write(down.getData());
                    File f = new File("./files/" + down.getFileName());
                    Files.write(f.toPath(), down.getData());
                    status2.setForeground(Color.GREEN);
                    status2.setText("Success");
                } catch (IOException | ClassNotFoundException e1) {
                    e1.printStackTrace();
                    status2.setText("Failed");
                    status2.setForeground(Color.red);
                }
                try {
                    connection.close();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
            }

        });
        addComponent( message, 1, 2, 1, 1 );
        addComponent( button1, 1, 1, 1, 1 );
        addComponent( status1, 1, 4, 2, 1 );
        addComponent(upload, 1,3,1,1);
        addComponent(downloads,2,1,2,1);
        addComponent(dlButton,2,3,1,1);
        addComponent(status2,2,4,1,1);

        setLocationRelativeTo(null);
        setSize( 600, 200 );
        setVisible( true );
    }

    private void addComponent( Component component,int row, int column, int width, int height )
    {
        // set gridx and gridy
        constraints.gridx = column;
        constraints.gridy = row;
        constraints.insets = new Insets(10,10,10,10);
        constraints.weightx = 1000; // can grow wider
        constraints.weighty = 1; // can grow taller
        constraints.fill = GridBagConstraints.BOTH;
        // set gridwidth and gridheight
        constraints.gridwidth = width;
        constraints.gridheight = height;
        // set constraints and add component
        layout.setConstraints( component, constraints );
        container.add( component );
    }

}
