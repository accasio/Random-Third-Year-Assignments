/**
 * Created by Seán on 08/11/2016.
 * 14336256
 */
import java.util.concurrent.BlockingQueue;
public class Producer extends Thread {
    private SyncQueue<String> queue;
    private int number;

    public Producer(SyncQueue queue, int number) {
        this.queue = queue;
        this.number = number;
    }

    public void run(){
        for (int i = 0; i < 3; i++) {
            try {
                System.out.println("Producer #" + this.number + " inserted: " + i +". "+Integer.toString(queue.getSize() + 1) +" item(s) in queue.");
                queue.add(Integer.toString(i) +" from Producer " +Integer.toString(this.number) );
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            try {
                sleep((int)(Math.random() * 10));
            } catch (InterruptedException e) { }
        }
    }
}
